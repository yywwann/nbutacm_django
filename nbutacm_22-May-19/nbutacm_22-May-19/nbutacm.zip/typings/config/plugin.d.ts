// This file is created by egg-ts-helper
// Do not modify this file!!!!!!!!!

import 'egg';
import 'egg-view-nunjucks';
import 'egg-mysql';